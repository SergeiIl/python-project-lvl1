# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games',
 'brain_games..venv.Lib.site-packages',
 'brain_games..venv.Lib.site-packages.pip',
 'brain_games..venv.Lib.site-packages.pip._internal',
 'brain_games..venv.Lib.site-packages.pip._internal.cli',
 'brain_games..venv.Lib.site-packages.pip._internal.commands',
 'brain_games..venv.Lib.site-packages.pip._internal.distributions',
 'brain_games..venv.Lib.site-packages.pip._internal.models',
 'brain_games..venv.Lib.site-packages.pip._internal.operations',
 'brain_games..venv.Lib.site-packages.pip._internal.req',
 'brain_games..venv.Lib.site-packages.pip._internal.utils',
 'brain_games..venv.Lib.site-packages.pip._internal.vcs',
 'brain_games..venv.Lib.site-packages.pip._vendor',
 'brain_games..venv.Lib.site-packages.pip._vendor.cachecontrol',
 'brain_games..venv.Lib.site-packages.pip._vendor.cachecontrol.caches',
 'brain_games..venv.Lib.site-packages.pip._vendor.certifi',
 'brain_games..venv.Lib.site-packages.pip._vendor.chardet',
 'brain_games..venv.Lib.site-packages.pip._vendor.chardet.cli',
 'brain_games..venv.Lib.site-packages.pip._vendor.colorama',
 'brain_games..venv.Lib.site-packages.pip._vendor.distlib',
 'brain_games..venv.Lib.site-packages.pip._vendor.distlib._backport',
 'brain_games..venv.Lib.site-packages.pip._vendor.html5lib',
 'brain_games..venv.Lib.site-packages.pip._vendor.html5lib._trie',
 'brain_games..venv.Lib.site-packages.pip._vendor.html5lib.filters',
 'brain_games..venv.Lib.site-packages.pip._vendor.html5lib.treeadapters',
 'brain_games..venv.Lib.site-packages.pip._vendor.html5lib.treebuilders',
 'brain_games..venv.Lib.site-packages.pip._vendor.html5lib.treewalkers',
 'brain_games..venv.Lib.site-packages.pip._vendor.idna',
 'brain_games..venv.Lib.site-packages.pip._vendor.lockfile',
 'brain_games..venv.Lib.site-packages.pip._vendor.msgpack',
 'brain_games..venv.Lib.site-packages.pip._vendor.packaging',
 'brain_games..venv.Lib.site-packages.pip._vendor.pep517',
 'brain_games..venv.Lib.site-packages.pip._vendor.pkg_resources',
 'brain_games..venv.Lib.site-packages.pip._vendor.progress',
 'brain_games..venv.Lib.site-packages.pip._vendor.pytoml',
 'brain_games..venv.Lib.site-packages.pip._vendor.requests',
 'brain_games..venv.Lib.site-packages.pip._vendor.urllib3',
 'brain_games..venv.Lib.site-packages.pip._vendor.urllib3.contrib',
 'brain_games..venv.Lib.site-packages.pip._vendor.urllib3.contrib._securetransport',
 'brain_games..venv.Lib.site-packages.pip._vendor.urllib3.packages',
 'brain_games..venv.Lib.site-packages.pip._vendor.urllib3.packages.backports',
 'brain_games..venv.Lib.site-packages.pip._vendor.urllib3.packages.rfc3986',
 'brain_games..venv.Lib.site-packages.pip._vendor.urllib3.packages.ssl_match_hostname',
 'brain_games..venv.Lib.site-packages.pip._vendor.urllib3.util',
 'brain_games..venv.Lib.site-packages.pip._vendor.webencodings',
 'brain_games..venv.Lib.site-packages.pkg_resources',
 'brain_games..venv.Lib.site-packages.pkg_resources._vendor',
 'brain_games..venv.Lib.site-packages.pkg_resources._vendor.packaging',
 'brain_games..venv.Lib.site-packages.pkg_resources.extern',
 'brain_games..venv.Lib.site-packages.setuptools',
 'brain_games..venv.Lib.site-packages.setuptools._vendor',
 'brain_games..venv.Lib.site-packages.setuptools._vendor.packaging',
 'brain_games..venv.Lib.site-packages.setuptools.command',
 'brain_games..venv.Lib.site-packages.setuptools.extern',
 'brain_games.scripts']

package_data = \
{'': ['*'],
 'brain_games': ['.venv/*',
                 '.venv/Lib/site-packages/pip-19.2.3.dist-info/*',
                 '.venv/Lib/site-packages/setuptools-41.2.0.dist-info/*',
                 '.venv/Scripts/*']}

entry_points = \
{'console_scripts': ['brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'sergeiil-brain-games',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
